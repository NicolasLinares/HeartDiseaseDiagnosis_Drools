package enfermedades;

public abstract class Enfermedad {

	protected String causa;

	public String getCausa() {
		return causa;
	}
	

	
}

package enfermedades;

public class ContraccionPrematuraVentricular extends Enfermedad {
	
	protected int ciclo;

	public ContraccionPrematuraVentricular(String causa, int ciclo) {
		super();
		this.causa = causa;
		this.ciclo = ciclo;
	}

	public int getCiclo() {
		return ciclo;
	}
	
}

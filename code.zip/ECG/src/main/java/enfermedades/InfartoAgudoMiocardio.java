package enfermedades;

public class InfartoAgudoMiocardio extends Enfermedad {
	
	protected int ciclo;

	public InfartoAgudoMiocardio(String causa, int ciclo) {
		super();
		this.causa = causa;
		this.ciclo = ciclo;
	}

	public int getCiclo() {
		return ciclo;
	}
	
}

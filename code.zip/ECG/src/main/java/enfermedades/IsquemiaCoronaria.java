package enfermedades;

public class IsquemiaCoronaria extends Enfermedad {

	protected int ciclo;

	public IsquemiaCoronaria(String causa, int ciclo) {
		super();
		this.causa = causa;
		this.ciclo = ciclo;
	}

	public int getCiclo() {
		return ciclo;
	}
}

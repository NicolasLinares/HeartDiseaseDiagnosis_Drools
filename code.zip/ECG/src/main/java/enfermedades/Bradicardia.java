package enfermedades;

public class Bradicardia extends Enfermedad {

	public Bradicardia(String causa) {
		super();
		this.causa = causa;
	}
	
}

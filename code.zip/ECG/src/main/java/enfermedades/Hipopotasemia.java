package enfermedades;

public class Hipopotasemia extends Enfermedad {
	
	private int ciclo;
	
	public Hipopotasemia(String causa, int ciclo) {
		super();
		this.causa = causa;
		this.ciclo = ciclo;
	}

	public int getCiclo() {
		return ciclo;
	}
	
}

package enfermedades;

public class Hipocalcemia extends Enfermedad {
	
	private int ciclo;

	public Hipocalcemia(String causa, int ciclo) {
		super();
		this.causa = causa;
		this.ciclo = ciclo;
	}

	public int getCiclo() {
		return ciclo;
	}
	
	
}

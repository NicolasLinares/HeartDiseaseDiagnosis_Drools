package enfermedades;

public class Taquicardia extends Enfermedad {

	public Taquicardia(String causa) {
		super();
		this.causa = causa;
	}
	
}

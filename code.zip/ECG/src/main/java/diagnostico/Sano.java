package diagnostico;

public class Sano extends Estado {
	
	private String estado;
	
	public Sano(String estado) {
		this.estado = estado;
	}

	@Override
	public int getNEnfermedades() {
		return 0; // Ninguna enfermedad
	}

	public String getEstado() {
		return estado;
	}
	
	

}

package diagnostico;

public class Diagnostico {

	private Estado estado;
	
	public Diagnostico(Estado estado) {
		this.setEstado(estado);
	}

	public Estado getEstado() {
		return estado;
	}

	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	
}

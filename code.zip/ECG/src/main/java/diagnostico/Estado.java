package diagnostico;

public abstract class Estado {
	
	protected int nEnfermedades;
	
	public abstract int getNEnfermedades();
}

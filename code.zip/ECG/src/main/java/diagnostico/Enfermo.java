package diagnostico;

import java.util.LinkedList;

import enfermedades.Enfermedad;

public class Enfermo extends Estado {

	private LinkedList<Enfermedad> enfermedades;

	public Enfermo() {
		super();
		this.enfermedades = new LinkedList<Enfermedad>();
		this.nEnfermedades = 0;
	}

	public void addEnfermedad(Enfermedad enfermedad) {
		this.nEnfermedades++;
		this.enfermedades.add(enfermedad);
	}
	
	public LinkedList<Enfermedad> getEnfermedades() {
		return enfermedades;
	}

	@Override
	public int getNEnfermedades() {
		return nEnfermedades;
	}
	
}

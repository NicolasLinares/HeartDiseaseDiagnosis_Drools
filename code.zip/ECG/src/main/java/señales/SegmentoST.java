package se�ales;

public class SegmentoST extends Segmento {
	
	public SegmentoST(int start, int end, int ciclo) {
		super();
		this.start = start;
		this.end = end;
		this.ciclo = ciclo;
	}
	
}

package se�ales;

public class SegmentoPQ extends Segmento {
	
	public SegmentoPQ(int start, int end, int ciclo) {
		super();
		this.start = start;
		this.end = end;
		this.ciclo = ciclo;
	}
	
}

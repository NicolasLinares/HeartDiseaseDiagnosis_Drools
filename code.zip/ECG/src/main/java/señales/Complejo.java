package se�ales;

public abstract class Complejo extends Componente {

}

package se�ales;

import java.util.LinkedList;

public class CicloCardiaco {

	private LinkedList<Componente> ciclo; // Latido del coraz�n
	private int duracionTotal; // Milisegundos
	
	public CicloCardiaco() {
		super();
		this.ciclo = new LinkedList<Componente>();
		this.duracionTotal = 0;
	}

	public LinkedList<Componente> getCiclo() {
		return ciclo;
	}

	public void addComponente(Componente componente) {
		
		// Se va calculando la duraci�n total del ciclo por si fuese necesario
		this.duracionTotal += componente.getDuracionReal();
		this.ciclo.addLast(componente);
	}

	public int getDuracionCiclo() {
		return duracionTotal;
	}
	
	
}

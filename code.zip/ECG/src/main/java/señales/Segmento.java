package se�ales;

public abstract class Segmento extends Componente {
	
}

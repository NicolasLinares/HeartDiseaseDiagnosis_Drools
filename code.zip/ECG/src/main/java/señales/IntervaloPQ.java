package se�ales;

public class IntervaloPQ extends Intervalo{

	public IntervaloPQ(int start, int end, int ciclo) {
		super();
		this.start = start;
		this.end = end;
		this.ciclo = ciclo;
	}
	
}

package se�ales;

public class U extends Se�al {
	
	public U(int start, int end, float peak, int ciclo) {
		super();
		this.start = start;
		this.end = end;
		this.peak = peak;
		this.ciclo = ciclo;
	}
	
}
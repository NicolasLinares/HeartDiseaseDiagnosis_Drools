package se�ales;

public class ComplejoQRS extends Complejo {

	public ComplejoQRS(int start, int end, int ciclo) {
		super();
		this.start = start;
		this.end = end;
		this.ciclo = ciclo;
	}
	
}

package se�ales;

public class R extends Se�al {
	
	public R(int start, int end, float peak, int ciclo) {
		super();
		this.start = start;
		this.end = end;
		this.peak = peak;
		this.ciclo = ciclo;
	}
}
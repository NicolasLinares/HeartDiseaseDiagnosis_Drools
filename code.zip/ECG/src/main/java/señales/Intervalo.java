package se�ales;

public abstract class Intervalo extends Componente {

}

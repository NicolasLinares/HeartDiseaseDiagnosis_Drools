package se�ales;

public class IntervaloQT extends Intervalo{

	public IntervaloQT(int start, int end, int ciclo) {
		super();
		this.start = start;
		this.end = end;
		this.ciclo = ciclo;
	}
	
}

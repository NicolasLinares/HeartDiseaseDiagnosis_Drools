package se�ales;

import se�ales.Se�al;

public class P extends Se�al {
	
	public P(int start, int end, float peak, int ciclo) {
		super();
		this.start = start;
		this.end = end;
		this.peak = peak;
		this.ciclo = ciclo;
	}
}

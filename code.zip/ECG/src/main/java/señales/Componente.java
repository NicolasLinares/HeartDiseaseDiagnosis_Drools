package se�ales;

public abstract class Componente  {
	
	protected int start;
	protected int end;
	protected int ciclo; // Ciclo al que pertenece el componente
	
	public int getStart() {
		return start;
	}

	public int getEnd() {
		return end;
	}

	public int getDuracionReal() {
		return end - start;
	}
	
	public int getIdCiclo() {
		return ciclo;
	}
	
}

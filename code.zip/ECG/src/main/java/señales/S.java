package se�ales;

public class S extends Se�al {
	
	public S(int start, int end, float peak, int ciclo) {
		super();
		this.start = start;
		this.end = end;
		this.peak = peak;
		this.ciclo = ciclo;
	}
}

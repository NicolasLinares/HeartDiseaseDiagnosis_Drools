package se�ales;

public abstract class Se�al extends Componente {

	protected float peak;
	
	public float getPeak() {
		return peak;
	}
	

}

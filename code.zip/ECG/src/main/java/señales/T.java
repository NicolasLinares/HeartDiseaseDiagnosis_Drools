package se�ales;

public class T extends Se�al {
	
	public T (int start, int end, float peak, int ciclo) {
		super();
		this.start = start;
		this.end = end;
		this.peak = peak;
		this.ciclo = ciclo;
	}
}

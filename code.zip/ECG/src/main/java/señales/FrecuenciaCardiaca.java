package se�ales;

public class FrecuenciaCardiaca {
	
	private int ciclosTotales;
	private int bpm;
	
	public FrecuenciaCardiaca() {
		super();
		this.ciclosTotales = 0;
		this.bpm = 0;
	}
	
	public int getNumeroCiclos() {
		return ciclosTotales;
	}

	public void setNumeroCiclos(int ciclosTotales) {
		this.ciclosTotales = ciclosTotales;
	}

	public int getBPM() {
		return this.bpm;
	}

	public void setBPM(int bpm) {
		this.bpm = bpm;
	}


}

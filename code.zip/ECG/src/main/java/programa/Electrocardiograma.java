package programa;

import java.util.LinkedList;
import se�ales.P;
import se�ales.Q;
import se�ales.R;
import se�ales.S;
import se�ales.T;
import se�ales.U;
import se�ales.Se�al;
import se�ales.FrecuenciaCardiaca;
import se�ales.Componente;

public class Electrocardiograma {
	
	private LinkedList<Componente> componentesECG;
	private FrecuenciaCardiaca frecuencia;
	
	private static Electrocardiograma unicaInstancia = null; 
	
	// Patr�n Singleton
	public static Electrocardiograma getDatosIniciales() {
		if (unicaInstancia == null)
			unicaInstancia = new Electrocardiograma();
				
		return unicaInstancia;
	}
	
	private Electrocardiograma() {
		super();
		this.componentesECG = new LinkedList<Componente>();
		this.frecuencia = new FrecuenciaCardiaca();
	}
		
	public FrecuenciaCardiaca getFrecuencia() {
		return this.frecuencia;
	}

	public LinkedList<Componente> getCiclos() {
		return componentesECG;
	}
	
	public void addSe�al(String tipo, int start, int end, float peak, int nuevoCiclo) {
		
		Se�al nueva = null;
		
		if (tipo.contains("P"))
			nueva = new P(start, end, peak, nuevoCiclo);
		if (tipo.contains("Q"))
			nueva = new Q(start, end, peak, nuevoCiclo);
		if (tipo.contains("R"))
			nueva = new R(start, end, peak, nuevoCiclo);
		if (tipo.contains("S"))
			nueva = new S(start, end, peak, nuevoCiclo);			
		if (tipo.contains("T"))
			nueva = new T(start, end, peak, nuevoCiclo);
		if (tipo.contains("U"))
			nueva = new U(start, end, peak, nuevoCiclo);
		
		if (nueva == null)
			System.err.println("Error en Electrocardiograma:addSe�al(), el tipo de la se�al no est� permitido: \n" + tipo);
		else
			componentesECG.addLast(nueva);
	}

	public void setFrecuencia(int bpm, int ciclos) {
		this.frecuencia.setBPM(bpm);
		this.frecuencia.setNumeroCiclos(ciclos);
	}

	public LinkedList<Componente> getComponentesECG() {
		return componentesECG;
	}
	
}
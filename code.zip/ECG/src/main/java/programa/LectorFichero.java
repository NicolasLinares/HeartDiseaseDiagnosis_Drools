package programa;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class LectorFichero {
		
	private String fichero;
	private FileReader fr;
	private BufferedReader br;
	
	private String regex1 = "[0-9]+"; // Para obtener los ciclos y el heart rate
	private String regex2 = "[^a-zA-Z\\(\\)]+"; // Para obetener los datos de la se�al (interior de los par�ntesis): (start, end, peak)

	public LectorFichero(String fichero) {
		this.fichero = fichero;
		try {
			this.fr = new FileReader(fichero);
		} catch (FileNotFoundException e) {
			System.err.println("Error al leer el fichero " + fichero + " : " + e);
		}
		this.br= new BufferedReader(fr);
	}

	
	public Electrocardiograma leerFichero(Electrocardiograma HI) {
				
		try {

			String linea;
			
			// Evitamos la primera l�nea que contiene el resultado
			linea = br.readLine(); 
			
			// Leemos el n�mero de ciclos
			linea = br.readLine();
			int ciclos = getNumero(linea);
			
			// Leemos los latidos por minuto
			linea = br.readLine();
			int bpm =  getNumero(linea);
			
			HI.setFrecuencia(bpm, ciclos);
			
			// L�nea en blanco
			linea = br.readLine();
			
			// Leemos las se�ales y las a�adimos a la base de hechos iniciales
			int nuevoCiclo = 0;
			while ((linea = br.readLine()) != null) {
				
				String tipo = getTipoSe�al(linea);	
				
				String[] datos = getDatosSe�al(linea);
				int start = Integer.parseInt(datos[0]);
				int end = Integer.parseInt(datos[1]);
				float peak = Float.parseFloat(datos[2]);
				
				if (tipo.contains("P"))
					nuevoCiclo++; // Si encontramos una P es el comienzo de un nuevo ciclo
				HI.addSe�al(tipo, start, end, peak, nuevoCiclo);
				
			}
			
		} catch (Exception e) {
			System.err.println("Error en LectorFichero:leerFichero(), no se ha podido leer el fichero " + fichero + ": " + e);
		
		} finally {

	         try{                    
	            if( null != fr ){   
	               fr.close();     
	            }                  
	         }catch (Exception e2){ 
	            e2.printStackTrace();
	         }
	     }
		
		return HI;
	}
	

	public int getNumero(String linea) {
		
		Pattern pattern = Pattern.compile(regex1);
		Matcher matcher = pattern.matcher(linea);
		matcher.find();
		return Integer.parseInt(matcher.group(0));
	}

	public String getTipoSe�al(String linea) {
		
		// Obtenemos el primer caracter de la l�nea correspondiente al tipo de se�al
		String[] datos = linea.split("\\(");
		return datos[0];
	}
	
	public String[] getDatosSe�al(String linea) {
		
		// Obtiene de la l�nea completa el siguiente segmento: 0,100,-0.27989623669747854
		Pattern pattern1 = Pattern.compile(regex2);
		Matcher matcher = pattern1.matcher(linea);
		matcher.find();
		
		// Separamos los distintos valores por cada coma
		linea = matcher.group(0);
		String[] datos = linea.split(",", 3);
		
		return datos;
	}	

}

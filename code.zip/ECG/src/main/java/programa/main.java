package programa;

import java.util.LinkedList;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.Agenda;

import se�ales.Componente;
import se�ales.U;

public class main {
	
	public static void main(String[] args) {
		
		// Se lee el fichero y se inicializan los hechos inicial
		Electrocardiograma hechosIniciales = Electrocardiograma.getDatosIniciales();
		LectorFichero lf = new LectorFichero(args[0]);
		
		System.out.println("---------------------------------------------------------------------------------" );
		System.out.println("Fichero: " + args[0] );
		System.out.println("---------------------------------------------------------------------------------" );

		lf.leerFichero(hechosIniciales);
		
		// ##########################################################################################
		
		// Cargamos la base de conocimiento
		KieServices ks = KieServices.Factory.get();
		KieContainer KContainer = ks.getKieClasspathContainer();
		
		// Creamos la primera sesi�n para el c�lculo de segmentos, intervalos y complejos
		KieSession kSession1 = KContainer.newKieSession("ksession1");  

		Agenda agenda = kSession1.getAgenda();
		agenda.getAgendaGroup( "mostrar" ).setFocus();		
		agenda.getAgendaGroup( "deteccion" ).setFocus();
		agenda.getAgendaGroup( "insertar" ).setFocus(); 
		
		//Insertamos los hechos: la frecuencia que contiene los ciclos y el bpm, y cada una de las se�ales
		kSession1.insert(hechosIniciales.getFrecuencia());
		LinkedList<Componente> se�ales = hechosIniciales.getComponentesECG();
		for (Componente s : se�ales)
			kSession1.insert(s);
			
		// Lanzamos las reglas para que calculen los intervalos, los segmentos y los complejos
		kSession1.fireAllRules();

	}
}

